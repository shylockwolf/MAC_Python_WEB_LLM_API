
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { ModelType, Message, DebugLog, FileInfo } from './types';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import DebugConsole from './components/DebugConsole';
import { Terminal, Github } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const App: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.GEMINI_FLASH);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '您好！我是您的 Gemini AI 助手。我已经准备好为您服务了。',
      timestamp: Date.now(),
    },
  ]);
  const [logs, setLogs] = useState<DebugLog[]>([]);
  const [showDebug, setShowDebug] = useState(true);

  const addLog = useCallback((type: DebugLog['type'], title: string, payload: any) => {
    const newLog: DebugLog = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      type,
      model: selectedModel,
      title,
      payload,
    };
    setLogs(prev => [newLog, ...prev].slice(0, 100));
  }, [selectedModel]);

  /**
   * Integrate real Google Gemini API logic.
   * Handles text and multi-modal file attachments.
   */
  const handleSendMessage = useCallback(async (content: string, files: FileInfo[]) => {
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: Date.now(),
      files,
    };
    setMessages(prev => [...prev, userMsg]);

    // Construct Gemini prompt parts (text + files)
    const parts: any[] = [{ text: content }];
    files.forEach(f => {
      if (f.data && f.type) {
        parts.push({
          inlineData: {
            mimeType: f.type,
            data: f.data,
          }
        });
      }
    });

    // Log the API request
    addLog('request', `Send to ${selectedModel}`, {
      model: selectedModel,
      contents: { parts },
      config: { temperature: 0.7 }
    });

    try {
      /**
       * Initialization: Always use a named parameter for the API key from process.env.API_KEY.
       * A new instance is created per request to ensure use of the latest environment configuration.
       */
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: { parts },
        config: {
          temperature: 0.7,
        }
      });

      // Extract generated text directly from the .text property
      const responseText = response.text || "Model returned no response.";

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responseText,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, assistantMsg]);
      
      // Log successful response
      addLog('response', `Received from ${selectedModel}`, response);

    } catch (error: any) {
      console.error("Gemini API Error:", error);
      addLog('error', `API Failure`, {
        message: error.message,
        stack: error.stack
      });

      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Sorry, an error occurred while connecting to Gemini: ${error.message || 'Unknown error'}.`,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMsg]);
    }
  }, [selectedModel, addLog]);

  return (
    <div className="flex h-screen w-full bg-[#09090b] text-zinc-100 overflow-hidden font-sans">
      {/* Sidebar - Model Selection & Config */}
      <Sidebar 
        selectedModel={selectedModel} 
        onSelectModel={setSelectedModel} 
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden border-x border-zinc-800">
        <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-950/50 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${selectedModel === ModelType.GEMINI_PRO ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-blue-500 shadow-[0_0_10px_#3b82f6]'}`} />
            <h1 className="font-semibold text-lg">
              {selectedModel === ModelType.GEMINI_FLASH ? 'Gemini Flash' : 'Gemini Pro'} Interface
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowDebug(!showDebug)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-all ${showDebug ? 'bg-zinc-800 text-zinc-100' : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300'}`}
            >
              <Terminal size={16} />
              Debug View
            </button>
            <div className="w-px h-4 bg-zinc-800" />
            <Github size={20} className="text-zinc-500 cursor-pointer hover:text-white transition-colors" />
          </div>
        </header>

        {/* Chat Component */}
        <ChatWindow 
          messages={messages} 
          onSend={handleSendMessage} 
          selectedModel={selectedModel}
        />
      </main>

      {/* Debug Panel */}
      {showDebug && (
        <DebugConsole 
          logs={logs} 
          onClose={() => setShowDebug(false)} 
        />
      )}
    </div>
  );
};

export default App;
